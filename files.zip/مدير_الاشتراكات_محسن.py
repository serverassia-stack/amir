# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
from datetime import datetime

class مدير_الاشتراكات:
    def __init__(self, نافذة):
        self.نافذة = نافذة
        self.نافذة.title("مدير الاشتراكات - الإصدار السهل")
        self.نافذة.geometry("900x600")
        
        self.ملف_البيانات = "اشتراكاتي.json"
        self.البيانات = self.تحميل_البيانات()
        self.إنشاء_الواجهة()
        self.تحديث_القائمة()
    
    def تحميل_البيانات(self):
        if os.path.exists(self.ملف_البيانات):
            try:
                with open(self.ملف_البيانات, 'r', encoding='utf-8') as ملف:
                    return json.load(ملف)
            except:
                return []
        else:
            return [
                {"اسم": "نيتفليكس", "تاريخ": "2024-02-15", "سعر": 45, "فئة": "ترفيه", "ملاحظات": "بريميوم"},
                {"اسم": "يوتيوب", "تاريخ": "2024-03-01", "سعر": 35, "فئة": "ترفيه", "ملاحظات": "موسيقى"},
                {"اسم": "أمازون", "تاريخ": "2024-01-20", "سعر": 40, "فئة": "تسوق", "ملاحظات": "شحن مجاني"}
            ]
    
    def حفظ_البيانات(self):
        with open(self.ملف_البيانات, 'w', encoding='utf-8') as ملف:
            json.dump(self.البيانات, ملف, ensure_ascii=False, indent=2)
    
    def إنشاء_الواجهة(self):
        إطار_رئيسي = ttk.Frame(self.نافذة, padding=10)
        إطار_رئيسي.pack(fill=tk.BOTH, expand=True)
        
        عنوان = ttk.Label(إطار_رئيسي, text="📅 مدير الاشتراكات الشخصي", font=('Arial', 18, 'bold'))
        عنوان.pack(pady=10)
        
        إطار_إدخال = ttk.LabelFrame(إطار_رئيسي, text="إضافة اشتراك جديد", padding=10)
        إطار_إدخال.pack(fill=tk.X, pady=10)
        
        صف1 = ttk.Frame(إطار_إدخال)
        صف1.pack(fill=tk.X, pady=5)
        ttk.Label(صف1, text="اسم الاشتراك:").pack(side=tk.LEFT, padx=5)
        self.مدخل_الاسم = ttk.Entry(صف1, width=25)
        self.مدخل_الاسم.pack(side=tk.LEFT, padx=5)
        ttk.Label(صف1, text="تاريخ الانتهاء:").pack(side=tk.LEFT, padx=5)
        self.مدخل_التاريخ = ttk.Entry(صف1, width=15)
        self.مدخل_التاريخ.pack(side=tk.LEFT, padx=5)
        ttk.Label(صف1, text="(YYYY-MM-DD)").pack(side=tk.LEFT)
        
        صف2 = ttk.Frame(إطار_إدخال)
        صف2.pack(fill=tk.X, pady=5)
        ttk.Label(صف2, text="السعر الشهري:").pack(side=tk.LEFT, padx=5)
        self.مدخل_السعر = ttk.Entry(صف2, width=15)
        self.مدخل_السعر.pack(side=tk.LEFT, padx=5)
        ttk.Label(صف2, text="الفئة:").pack(side=tk.LEFT, padx=5)
        self.قائمة_الفئة = ttk.Combobox(صف2, width=12, values=["ترفيه", "تعليم", "أعمال", "تسوق", "أخرى"])
        self.قائمة_الفئة.set("ترفيه")
        self.قائمة_الفئة.pack(side=tk.LEFT, padx=5)
        
        أزرار = ttk.Frame(إطار_إدخال)
        أزرار.pack(pady=10)
        ttk.Button(أزرار, text="➕ إضافة اشتراك", command=self.إضافة_اشتراك).pack(side=tk.LEFT, padx=5)
        ttk.Button(أزرار, text="🗑️ حذف مختار", command=self.حذف_مختار).pack(side=tk.LEFT, padx=5)
        ttk.Button(أزرار, text="📊 إحصائيات", command=self.عرض_إحصائيات).pack(side=tk.LEFT, padx=5)
        ttk.Button(أزرار, text="🔄 تحديث", command=self.تحديث_القائمة).pack(side=tk.LEFT, padx=5)
        
        إطار_القائمة = ttk.LabelFrame(إطار_رئيسي, text="قائمة اشتراكاتي", padding=10)
        إطار_القائمة.pack(fill=tk.BOTH, expand=True, pady=10)
        
        أعمدة = ('الاسم', 'التاريخ', 'السعر', 'الفئة', 'الحالة', 'الأيام')
        self.جدول = ttk.Treeview(إطار_القائمة, columns=أعمدة, show='headings', height=15)
        self.جدول.heading('الاسم', text='اسم الاشتراك')
        self.جدول.heading('التاريخ', text='تاريخ الانتهاء')
        self.جدول.heading('السعر', text='السعر')
        self.جدول.heading('الفئة', text='الفئة')
        self.جدول.heading('الحالة', text='الحالة')
        self.جدول.heading('الأيام', text='الأيام المتبقية')
        self.جدول.column('الاسم', width=180)
        self.جدول.column('التاريخ', width=100)
        self.جدول.column('السعر', width=80)
        self.جدول.column('الفئة', width=80)
        self.جدول.column('الحالة', width=100)
        self.جدول.column('الأيام', width=100)
        شريط_تمرير = ttk.Scrollbar(إطار_القائمة, orient=tk.VERTICAL, command=self.جدول.yview)
        self.جدول.configure(yscrollcommand=شريط_تمرير.set)
        self.جدول.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        شريط_تمرير.pack(side=tk.RIGHT, fill=tk.Y)
        self.جدول.bind('<Double-1>', self.عرض_تفاصيل)
    
    def إضافة_اشتراك(self):
        اسم = self.مدخل_الاسم.get().strip()
        تاريخ = self.مدخل_التاريخ.get().strip()
        سعر_نص = self.مدخل_السعر.get().strip()
        فئة = self.قائمة_الفئة.get()
        if not اسم:
            messagebox.showerror("خطأ", "يرجى إدخال اسم الاشتراك")
            return
        if not تاريخ:
            messagebox.showerror("خطأ", "يرجى إدخال تاريخ الانتهاء")
            return
        try:
            datetime.strptime(تاريخ, '%Y-%m-%d')
        except ValueError:
            messagebox.showerror("خطأ", "تنسيق التاريخ غير صحيح\nاستخدم الصيغة: 2024-12-31")
            return
        try:
            سعر = float(سعر_نص) if سعر_نص else 0.0
            if سعر < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("خطأ", "يرجى إدخال سعر صحيح (غير سلبي)")
            return
        # التحقق من التكرار
        for اشتراك in self.البيانات:
            if اشتراك["اسم"] == اسم and اشتراك["تاريخ"] == تاريخ:
                messagebox.showerror("خطأ", "هذا الاشتراك مسجل بالفعل بنفس التاريخ")
                return
        اشتراك_جديد = {"اسم": اسم, "تاريخ": تاريخ, "سعر": سعر, "فئة": فئة, "ملاحظات": ""}
        self.البيانات.append(اشتراك_جديد)
        self.حفظ_البيانات()
        messagebox.showinfo("تم بنجاح", f"تم إضافة اشتراك '{اسم}'")
        self.مدخل_الاسم.delete(0, tk.END)
        self.مدخل_التاريخ.delete(0, tk.END)
        self.مدخل_السعر.delete(0, tk.END)
        self.تحديث_القائمة()
    
    def تحديث_القائمة(self):
        for عنصر in self.جدول.get_children():
            self.جدول.delete(عنصر)
        for اشتراك in self.البيانات:
            try:
                تاريخ_انتهاء = datetime.strptime(اشتراك['تاريخ'], '%Y-%m-%d')
                اليوم = datetime.now()
                أيام_متبقية = (تاريخ_انتهاء - اليوم).days
                if أيام_متبقية < 0:
                    حالة = "🛑 منتهي"
                    لون = "منتهي"
                    نص_أيام = "منتهي"
                elif أيام_متبقية == 0:
                    حالة = "⚠️ ينتهي اليوم"
                    لون = "عاجل"
                    نص_أيام = "اليوم"
                elif أيام_متبقية <= 7:
                    حالة = "🔶 قريب"
                    لون = "قريب"
                    نص_أيام = str(أيام_متبقية)
                else:
                    حالة = "✅ نشط"
                    لون = "نشط"
                    نص_أيام = str(أيام_متبقية)
            except:
                حالة = "❓ غير معروف"
                نص_أيام = "؟"
                لون = "نشط"
            self.جدول.insert(
                '', 'end', 
                values=(اشتراك['اسم'], اشتراك['تاريخ'], f"{اشتراك['سعر']:.2f} $", اشتراك['فئة'], حالة, نص_أيام), 
                tags=(لون,)
            )
        self.جدول.tag_configure('منتهي', background='#ffdddd')
        self.جدول.tag_configure('عاجل', background='#ffeedd')
        self.جدول.tag_configure('قريب', background='#ffffdd')
        self.جدول.tag_configure('نشط', background='#ddffdd')
    
    def حذف_مختار(self):
        مختار = self.جدول.selection()
        if not مختار:
            messagebox.showwarning("تنبيه", "يرجى اختيار اشتراك للحذف")
            return
        if messagebox.askyesno("تأكيد", "هل أنت متأكد من حذف هذا الاشتراك؟"):
            for عنصر in مختار:
                القيم = self.جدول.item(عنصر, "values")
                اسم = القيم[0]
                تاريخ = القيم[1]
                # البحث في البيانات وحذف أول تطابق
                for i, اشتراك in enumerate(self.البيانات):
                    if اشتراك["اسم"] == اسم and اشتراك["تاريخ"] == تاريخ:
                        del self.البيانات[i]
                        break
                self.جدول.delete(عنصر)
            self.حفظ_البيانات()
            messagebox.showinfo("تم", "تم الحذف بنجاح")
    
    def عرض_تفاصيل(self, event):
        مختار = self.جدول.selection()
        if مختار:
            القيم = self.جدول.item(مختار[0], "values")
            اسم = القيم[0]
            تاريخ = القيم[1]
            # البحث عن الاشتراك في البيانات
            اشتراك = next((s for s in self.البيانات if s["اسم"] == اسم and s["تاريخ"] == تاريخ), None)
            if اشتراك:
                تفاصيل = f"""
اسم الاشتراك: {اشتراك['اسم']}
تاريخ الانتهاء: {اشتراك['تاريخ']}
السعر الشهري: {اشتراك['سعر']:.2f} $
الفئة: {اشتراك['فئة']}
ملاحظات: {اشتراك.get('ملاحظات', 'لا توجد ملاحظات')}
                """
                messagebox.showinfo("تفاصيل الاشتراك", تفاصيل)
    
    def عرض_إحصائيات(self):
        if not self.البيانات:
            messagebox.showinfo("الإحصائيات", "لا توجد اشتراكات مسجلة")
            return
        عدد_الاشتراكات = len(self.البيانات)
        التكلفة_الشهرية = sum(اشتراك['سعر'] for اشتراك in self.البيانات)
        التكلفة_السنوية = التكلفة_الشهرية * 12
        منتهي = عاجل = قريب = نشط = 0
        for اشتراك in self.البيانات:
            try:
                تاريخ_انتهاء = datetime.strptime(اشتراك['تاريخ'], '%Y-%m-%d')
                أيام_متبقية = (تاريخ_انتهاء - datetime.now()).days
                if أيام_متبقية < 0:
                    منتهي += 1
                elif أيام_متبقية == 0:
                    عاجل += 1
                elif أيام_متبقية <= 7:
                    قريب += 1
                else:
                    نشط += 1
            except:
                pass
        توزيع_الفئات = {}
        for اشتراك in self.البيانات:
            فئة = اشتراك['فئة']
            توزيع_الفئات[فئة] = توزيع_الفئات.get(فئة, 0) + 1
        نص_الفئات = "\n".join([f"   • {فئة}: {عدد}" for فئة, عدد in توزيع_الفئات.items()])
        إحصائيات = f"""
📊 الإحصائيات الشاملة:

• إجمالي الاشتراكات: {عدد_الاشتراكات}
• التكلفة الشهرية: {التكلفة_الشهرية:.2f} $
• التكلفة السنوية: {التكلفة_السنوية:.2f} $

🎯 حالة الاشتراكات:
   • ✅ نشط: {نشط}
   • 🔶 قريب الانتهاء: {قريب}
   • ⚠️ عاجل: {عاجل}
   • 🛑 منتهي: {منتهي}

📂 التوزيع حسب الفئة:
{نص_الفئات}
        """
        messagebox.showinfo("التقارير والإحصائيات", إحصائيات)

if __name__ == "__main__":
    نافذة_رئيسية = tk.Tk()
    تطبيق = مدير_الاشتراكات(نافذة_رئيسية)
    نافذة_رئيسية.mainloop()